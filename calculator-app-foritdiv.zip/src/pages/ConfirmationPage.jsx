import { useLocation } from 'react-router-dom';

export default function ConfirmationPage({ darkMode }) {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const ticketNumber = queryParams.get('ticket');

  return (
    <div
      className={`container mx-auto px-4 py-8 ${
        darkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-black'
      }`}
    >
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-4">Ticket Submitted</h1>
        <p className="mb-4">
          Thank you for contacting support! Your ticket number is{' '}
          <span className="font-bold">{ticketNumber}</span>.
        </p>
        <p>
          We have sent the ticket details to your email. Our team will get back to you shortly.
        </p>
        <button
          onClick={() => (window.location.href = '/')}
          className={`mt-6 py-2 px-4 rounded font-bold ${
            darkMode
              ? 'bg-blue-600 hover:bg-blue-500 text-white'
              : 'bg-blue-400 hover:bg-blue-300 text-black'
          }`}
        >
          Back to Calculator
        </button>
      </div>
    </div>
  );
}
